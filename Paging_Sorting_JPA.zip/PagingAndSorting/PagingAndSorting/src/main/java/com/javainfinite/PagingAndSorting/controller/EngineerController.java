package com.javainfinite.PagingAndSorting.controller;

import com.javainfinite.PagingAndSorting.model.Engineer;
import com.javainfinite.PagingAndSorting.repository.EngineerDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class EngineerController {

    @Autowired
    private EngineerDAO eDao;

    @PostMapping("/saveEngineers")
    public Integer saveEngineers(@RequestBody List<Engineer> engineerList) {
        return eDao.saveEngineers(engineerList);
    }

    @GetMapping("/getPaginationEngineers")
    public Page<Engineer> getEngineers(@RequestParam("records") int records,
                                       @RequestParam("page") int page) {
        return eDao.getPagination(records, page);
    }

    @GetMapping("/getPaginationAndSortEngineers")
    public Page<Engineer> getEngineersAndSort(@RequestParam("records") int records,
                                              @RequestParam("page") int page,
                                              @RequestParam("sortField") String sortField) {
        return eDao.getPaginationAndSort(records, page, sortField);
    }
}

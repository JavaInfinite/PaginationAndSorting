package com.javainfinite.PagingAndSorting.service;

import com.javainfinite.PagingAndSorting.model.Engineer;
import com.javainfinite.PagingAndSorting.repository.EngineerDAO;
import com.javainfinite.PagingAndSorting.repository.EngineerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EngineerService implements EngineerDAO {

    @Autowired
    private EngineerRepository repository;

    @Override
    public Page<Engineer> getPagination(int records, int page) {

        Pageable pageable = PageRequest.of(page, records);
        return repository.findAll(pageable);
    }

    @Override
    public Page<Engineer> getPaginationAndSort(int records, int page, String sortField) {
        Pageable pageable = PageRequest.of(page, records, Sort.by(sortField));
        return repository.findAll(pageable);
    }

    @Override
    public Integer saveEngineers(List<Engineer> engineerList) {

        return repository.saveAll(engineerList).size();
    }
}

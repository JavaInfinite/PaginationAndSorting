package com.javainfinite.PagingAndSorting.repository;

import com.javainfinite.PagingAndSorting.model.Engineer;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EngineerDAO  {

    Page<Engineer> getPagination(int records, int page);

    Page<Engineer> getPaginationAndSort(int records, int page, String sortField);

    Integer saveEngineers(List<Engineer> engineerList);

}

package com.javainfinite.PagingAndSorting.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Engineer {

    @Id
    @GeneratedValue
    private int id;

    @Column(name = "Name")
    private String engineerName;

    @Column(name = "Department")
    private String engineerDepartment;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEngineerName() {
        return engineerName;
    }

    public void setEngineerName(String engineerName) {
        this.engineerName = engineerName;
    }

    public String getEngineerDepartment() {
        return engineerDepartment;
    }

    public void setEngineerDepartment(String engineerDepartment) {
        this.engineerDepartment = engineerDepartment;
    }
}
